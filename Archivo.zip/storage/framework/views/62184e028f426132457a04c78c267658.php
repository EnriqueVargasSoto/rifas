<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rifas GH</title>

    <!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('logo.png')); ?>">
	<link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
	<!-- Datatable -->
    <link href="<?php echo e(asset('admin/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('admin/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/style.css')); ?>" rel="stylesheet">
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
	<div id="preloader">
		<div>
			<img src="<?php echo e(asset('logo.png')); ?>" alt="">
		</div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="#" class="brand-logo" style="justify-content: center;">
				<img src="<?php echo e(asset('logo.png')); ?>" alt="" style="height: 60px;">
            </a>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

		<!--**********************************
            Chat box start
        ***********************************-->
		
		<!--**********************************
            Chat box End
        ***********************************-->




        <!--**********************************
            Header start
        ***********************************-->
        <?php echo $__env->make('intranet.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('intranet.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- container starts -->
            <div class="container-fluid">

                <!-- row -->
				<div class="element-area">
					<div class="demo-view" style="width: 100%">
						<div class="container-fluid pt-0 ps-0 pe-lg-4 pe-0">

                            <?php echo $__env->yieldContent('content'); ?>

                        <div>
                    </div>
				</div>
			</div>
        </div>
        <!--**********************************
                Content body end
            ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('intranet.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('admin/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
    <!-- Apex Chart -->
    <script src="<?php echo e(asset('admin/vendor/apexchart/apexchart.js')); ?>"></script>

    <!-- Datatable -->
    <script src="<?php echo e(asset('admin/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/plugins-init/datatables.init.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/deznav-init.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/demo.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/styleSwitcher.js')); ?>"></script>

    <!-- code-highlight -->
    <script src="<?php echo e(asset('admin/js/highlight.min.js')); ?>"></script>

</body>
</html>
<?php /**PATH /Volumes/Shegu/eber/rifas/resources/views/intranet/layouts/layout.blade.php ENDPATH**/ ?>