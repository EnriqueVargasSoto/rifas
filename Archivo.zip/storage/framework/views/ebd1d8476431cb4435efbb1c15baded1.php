<?php $__env->startSection('content'); ?>
<!-- Column starts -->
<div class="col-xl-12">
    <div class="card dz-card" id="accordion-four">
        <div class="card-header flex-wrap d-flex justify-content-between">
            <div>
                <h4 class="card-title">Rifas Asignadas</h4>
            </div>
            <ul class="" id="myTab-3" role="tablist">
                <!--<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#basicModal"><i class="fa-solid fa-plus me-2"></i>Nuevo Asignacion</button>-->
            </ul>
        </div>

            <!-- /tab-content -->
            <div class="tab-content" id="myTabContent-3">
                <div class="tab-pane fade show active" id="withoutBorder" role="tabpanel" aria-labelledby="home-tab-3">
                    <div class="card-body pt-0">
                        <div class="table-responsive">
                            <table id="example4" class="display table" style="min-width: 845px">
                                <thead>
                                    <tr>
                                        <th style="width: 15px">#</th>
                                        <th>Opción 1</th>
                                        <th>Opción 2</th>
                                        <th>Opción 3</th>
                                        <th>Rifa</th>
                                        <th>Estado</th>
                                        <th style="width:25px">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($detail->option1->name); ?></td>
                                        <td><?php echo e($detail->option2->name); ?></td>
                                        <td><?php echo e($detail->option3->name); ?></td>
                                        <td><?php echo e($detail->raffle->code); ?></td>
                                        <td><?php echo e($detail->raffle->selected == '0' ? 'Libre' : 'Ocupada'); ?></td>
                                        <td style="width:25px">
                                            
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        <!-- /tab-content -->

    </div>
</div>
<!-- Column ends -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('intranet.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Shegu/eber/rifas/resources/views/intranet/pages/assignment/detail/index.blade.php ENDPATH**/ ?>